/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicioaula04.pkg05;

/**
 *
 * @author autologon
 */
public class ExercicioAula0405 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Tela1 t1 = new Tela1();
        t1.setVisible(true);
    }
    
}
